package com.sk.intensive.library.common.base;

public interface AggregateRoot {
}
