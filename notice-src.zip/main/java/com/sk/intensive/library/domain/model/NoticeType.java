package com.sk.intensive.library.domain.model;

public enum NoticeType {
	NORMAL,
	EVENT,
	NEWBOOK
}
