package com.sk.intensive.library.domain.model;

public enum MembershipLevelType {
	VIP,
	GOLD,
	SILVER
}
