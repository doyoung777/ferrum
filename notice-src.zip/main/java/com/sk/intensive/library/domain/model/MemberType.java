package com.sk.intensive.library.domain.model;

public enum MemberType {
	SELLER,
	BUYER
}
